﻿using UnityEngine;
using System.Collections;

public class EnemySpawn3 : MonoBehaviour {
	
	public GameObject enemy1;
	public GameObject enemy2;
	public GameObject enemy3;
	public Transform spawnPoint1;
	public Transform spawnPoint2;
	public Transform spawnPoint3;

	void OnTriggerEnter (Collider other) {
		if(other.gameObject.tag == "Player") {
			Instantiate(enemy1, spawnPoint1.position, spawnPoint1.rotation);
			Instantiate(enemy2, spawnPoint2.position, spawnPoint2.rotation);
			Instantiate(enemy3, spawnPoint3.position, spawnPoint3.rotation);
			Destroy (gameObject);
		}
	}
}
