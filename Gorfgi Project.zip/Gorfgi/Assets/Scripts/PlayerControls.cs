﻿using UnityEngine;
using System.Collections;

public class PlayerControls : MonoBehaviour {

	NavMeshAgent navAgent;
	Light flashLight;
	public bool Controllable = true;
	public bool flashlightON;

	void Start () {
		navAgent = GetComponent<NavMeshAgent> ();
		flashLight = GetComponent<Light> ();
	}

	void Update () {
		RaycastHit hit;
		Ray ray = Camera.main.ScreenPointToRay (Input.mousePosition);

		if (Input.GetMouseButtonUp (0) && Controllable) {
			if(Physics.Raycast (ray, out hit, 100)){
				navAgent.SetDestination(hit.point);
			}
		}
		if (Input.GetMouseButtonDown (1) && Controllable) {
			if(Physics.Raycast (ray, out hit, 100)){
				transform.LookAt(hit.point);
			}
		}

		if(Input.GetKeyUp(KeyCode.F) && flashlightON == false && Controllable){
			flashLight.enabled = true;
			flashlightON = true;
		}
		else if(Input.GetKeyUp(KeyCode.F) && flashlightON == true && Controllable){
			flashLight.enabled = false;
			flashlightON = false;
		}
	}
}
