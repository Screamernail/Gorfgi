﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class PlayerHealth : MonoBehaviour {

	public int startingHealth = 100;
	public int currentHealth;

	public Text healthText;
	
	public AudioClip DeathClip;

	AudioSource PlayerAudio;
	PlayerControls playerControls;
	PlayerShooting playerShooting;
	bool isDead;

	void Start () {
		PlayerAudio = GetComponent<AudioSource> ();
		playerControls = GetComponent<PlayerControls> ();
		playerShooting = GetComponent<PlayerShooting> ();
		currentHealth = startingHealth;
	}
	

	void Update () {
		healthText.text = "Health: " + currentHealth;
	}

	public void TakeDamage (int amount){
		currentHealth -= amount;
		PlayerAudio.Play ();
		if (currentHealth <= 0 && !isDead) {
			Death();
		}
	}

	void Death(){
		isDead = true;
		PlayerAudio.clip = DeathClip;
		PlayerAudio.Play ();

		playerControls.enabled = false;
		playerShooting.enabled = false;
	}
}
