﻿using UnityEngine;
using System.Collections;

public class EnemyHealth : MonoBehaviour {

	public int startingHealth = 30;
	public int currentHealth;
	public AudioClip deathClip;

	AudioSource enemyAudio;
	BoxCollider boxCollider;
	bool isDead;

	void Start () {
		enemyAudio = GetComponent<AudioSource> ();
		boxCollider = GetComponent<BoxCollider> ();
		currentHealth = startingHealth;
	}
	

	void Update () {
	
	}

	public void TakeDamage(int amount, Vector3 hitPoint){
		if (isDead) {
			return;
		}
		enemyAudio.Play ();
		currentHealth -= amount;

		if (currentHealth <= 0) {
			Death();
		}
	}

	void Death(){
		isDead = true;

		boxCollider.isTrigger = true;
		enemyAudio.clip = deathClip;
		enemyAudio.Play ();
		Destroy (gameObject, 1f);
	}
}
