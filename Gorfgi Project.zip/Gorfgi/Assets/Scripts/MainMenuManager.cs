﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class MainMenuManager : MonoBehaviour {

	public Text FirstText;
	public Text SecondText;
	public Image NewGameImage;
	public GameObject NewGameBTN;
	public GameObject OptionsBTN;
	public GameObject QuitBTN;
	public GameObject ContinueBTN1;
	public GameObject ContinueBTN2;
	public GameObject OptionsPanel;
	

	public void NewGameSelect(){
		FirstText.enabled = true;
		NewGameImage.enabled = true;
		NewGameBTN.SetActive (false);
		OptionsBTN.SetActive (false);
		QuitBTN.SetActive (false);
		ContinueBTN1.SetActive (true);
	}

	public void ContinueStory(){
		ContinueBTN1.SetActive (false);
		ContinueBTN2.SetActive (true);
		FirstText.enabled = false;
		SecondText.enabled = true;
	}

	public void StartGame(){

		Application.LoadLevel ("Area1");
	}

	public void OptionSelect(){
		NewGameBTN.SetActive (false);
		OptionsBTN.SetActive (false);
		QuitBTN.SetActive (false);
		OptionsPanel.SetActive (true);
	}

	public void QuitGame(){
		Application.Quit ();
	}
}
