﻿using UnityEngine;
using System.Collections;

public class LevelEnd : MonoBehaviour {

	public Camera EndCam;
	public Camera MainCam;
	GameObject player;
	PlayerControls playercontrols;
	public GameObject EndText;
	public float EndTimer = 5f;
	public string NextLevel;
	bool LevelCompleted;

	void Start () {
		player = GameObject.FindGameObjectWithTag ("Player");
		playercontrols = player.gameObject.GetComponent<PlayerControls> ();
	}

	void Update () {
		if(LevelCompleted){
		EndTimer -= Time.deltaTime;
			if (EndTimer <= 0) {
				Application.LoadLevel (NextLevel);
			}
		}
	}

	void OnTriggerEnter (Collider other) {
		if (other.gameObject == player) {
			playercontrols.Controllable = false;
			EndText.SetActive (true);
			MainCam.enabled = false;
			EndCam.enabled = true;
			Time.timeScale = 0;
				LevelCompleted = true;
		}
	}
}
