﻿using UnityEngine;
using System.Collections;

public class ComputerScript1 : MonoBehaviour {

	public bool InRange;
	public Transform Computerpanel;
	public GameObject button1;
	public GameObject button2;
	public GameObject Backbutton;

	public GameObject Image1;
	public GameObject Image2;
	public GameObject Text1;
	public GameObject Text2;

	GameObject player;
	PlayerControls playercontrols;

	void Start () {
		player = GameObject.FindGameObjectWithTag ("Player");
		playercontrols = player.gameObject.GetComponent<PlayerControls> ();
	}

	void OnTriggerEnter (Collider other) {
		if (other.gameObject.tag == "Player") {
			InRange = true;
		}
	}
	
	void OnTriggerExit (Collider other) {
		if (other.gameObject.tag == "Player") {
			InRange = false;
		}
	}

	void Update () {
		if (Input.GetKeyDown (KeyCode.E) && InRange) {
			if(Computerpanel.gameObject.activeInHierarchy == false){
				Computerpanel.gameObject.SetActive(true);
				playercontrols.Controllable = false;
				
			}else{
				Computerpanel.gameObject.SetActive (false);
				playercontrols.Controllable = true;
			}
		}
	}

	public void Selection1 () {
		button1.SetActive (false);
		button2.SetActive (false);
		Backbutton.SetActive (true);
		Image1.SetActive (true);
		Text1.SetActive (true);
	}

	public void Selection2 () {
		button1.SetActive (false);
		button2.SetActive (false);
		Backbutton.SetActive (true);
		Image2.SetActive (true);
		Text2.SetActive (true);
	}

	public void BackToMenu () {
		button1.SetActive (true);
		button2.SetActive (true);
		Backbutton.SetActive (false);
		Image1.SetActive (false);
		Text1.SetActive (false);
		Image2.SetActive (false);
		Text2.SetActive (false);
	}
}
