﻿using UnityEngine;
using System.Collections;

public class RotateAround : MonoBehaviour {


	void Start () {
	
	}

	void Update () {
		transform.Rotate (new Vector3(Time.deltaTime * 0.10f,0.10f,0.10f));
	}
}
