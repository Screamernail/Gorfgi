﻿using UnityEngine;
using System.Collections;

public class EnemySpawn6 : MonoBehaviour {
	
	public GameObject enemy1;
	public GameObject enemy2;
	public GameObject enemy3;
	public GameObject enemy4;
	public GameObject enemy5;
	public GameObject enemy6;
	public Transform spawnPoint1;
	public Transform spawnPoint2;
	public Transform spawnPoint3;
	public Transform spawnPoint4;
	public Transform spawnPoint5;
	public Transform spawnPoint6;

	void OnTriggerEnter (Collider other) {
		if(other.gameObject.tag == "Player") {
			Instantiate(enemy1, spawnPoint1.position, spawnPoint1.rotation);
			Instantiate(enemy2, spawnPoint2.position, spawnPoint2.rotation);
			Instantiate(enemy3, spawnPoint3.position, spawnPoint3.rotation);
			Instantiate(enemy4, spawnPoint4.position, spawnPoint4.rotation);
			Instantiate(enemy5, spawnPoint5.position, spawnPoint5.rotation);
			Instantiate(enemy6, spawnPoint6.position, spawnPoint6.rotation);
			Destroy (gameObject);
		}
	}
}
