﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class SettingManager : MonoBehaviour {

	public Toggle fullScreenToggle;
	public Dropdown DifficultyDropdown;
	public Slider SoundVolume;

	public GameSettings gameSettings;

	void OnEnable () {
		gameSettings = new GameSettings ();

		fullScreenToggle.onValueChanged.AddListener (delegate {
			OnFullscreenToggle ();
		});
		SoundVolume.onValueChanged.AddListener (delegate {
			OnSoundVolumeChange ();
		});
	}
	

	public void OnFullscreenToggle () {
		gameSettings.fullScreen = Screen.fullScreen = fullScreenToggle.isOn;
	}

	public void OnDifficultyChange(){

	}

	public void OnSoundVolumeChange(){

	}
}
