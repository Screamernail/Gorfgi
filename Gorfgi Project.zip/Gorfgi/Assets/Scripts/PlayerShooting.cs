﻿using UnityEngine;
using System.Collections;

public class PlayerShooting : MonoBehaviour {

	public int DamagePerShot = 20;
	public float timeBetweenShots = 1f;
	public float range = 100f;

	float timer;
	Ray ShootRay;
	RaycastHit shootHit;
	int shootableMask;
	LineRenderer gunLine;
	AudioSource gunAudio;
	Light gunLight;
	float effectDisplayTime = 0.2f;

	void Start () {
		shootableMask = LayerMask.GetMask ("Shootable");

		gunLine = GetComponent<LineRenderer> ();
		gunAudio = GetComponent<AudioSource> ();
		gunLight = GetComponent<Light> ();
	}

	void Update () {
		timer += Time.deltaTime;
		if (Input.GetKeyDown (KeyCode.Space) && timer >= timeBetweenShots) {
			Shoot();
		}
		if (timer >= timeBetweenShots * effectDisplayTime) {
			DisableEffects();
		}
	}

	public void DisableEffects(){
		gunLine.enabled = false;
		gunLight.enabled = false;
	}

	void Shoot(){
		timer = 0f;
		gunAudio.Play ();
		gunLight.enabled = true;
		gunLine.enabled = true;
		gunLine.SetPosition (0, transform.position);
		ShootRay.origin = transform.position;
		ShootRay.direction = transform.forward;

		if (Physics.Raycast (ShootRay, out shootHit, range, shootableMask)) {
			EnemyHealth enemyHealth = shootHit.collider.GetComponent<EnemyHealth>();
			if(enemyHealth != null){
				enemyHealth.TakeDamage (DamagePerShot, shootHit.point);
			}
			gunLine.SetPosition (1, shootHit.point);
		} else {
			gunLine.SetPosition (1, ShootRay.origin + ShootRay.direction * range);
		}
	}
}
