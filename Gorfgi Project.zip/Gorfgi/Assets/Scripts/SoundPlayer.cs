﻿using UnityEngine;
using System.Collections;

public class SoundPlayer : MonoBehaviour {

	public AudioSource Source;

	void OnTriggerEnter (Collider other) {
		if(other.gameObject.tag == "Player")
		{
			Source.Play ();
		}
	}
}
