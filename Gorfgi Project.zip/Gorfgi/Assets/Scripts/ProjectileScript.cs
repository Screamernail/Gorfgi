﻿using UnityEngine;
using System.Collections;

public class ProjectileScript : MonoBehaviour {

	public int attackDamage = 20;

	void Start () {
	
	}

	void OnTriggerEnter (Collider other) {
	if (other.gameObject.tag == "Player") {
			PlayerHealth playerHealth = other.GetComponent<PlayerHealth>();
			if(playerHealth != null){
				playerHealth.TakeDamage (attackDamage);
			}
		}
	}
}
