﻿using UnityEngine;
using System.Collections;

public class Destroyer : MonoBehaviour {

	public GameObject ObjectToDestroy;

	void Start () {
	
	}

	void OnTriggerEnter (Collider other) {
		if (other.gameObject.tag == "Player") {
			Destroy (ObjectToDestroy);
		}
	}
}
