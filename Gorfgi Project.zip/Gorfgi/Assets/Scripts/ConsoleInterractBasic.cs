﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class ConsoleInterractBasic : MonoBehaviour {

	public bool InRange;
	public Transform Monitorpanel;
	public GameObject MonitorText;

	GameObject player;
	PlayerControls playercontrols;

	void Start () {
		player = GameObject.FindGameObjectWithTag ("Player");
		playercontrols = player.gameObject.GetComponent<PlayerControls> ();
	}

	void OnTriggerEnter (Collider other) {
	if (other.gameObject.tag == "Player") {
			InRange = true;
		}
	}

	void OnTriggerExit (Collider other) {
		if (other.gameObject.tag == "Player") {
			InRange = false;
		}
	}


	void Update () {
		if (Input.GetKeyDown (KeyCode.E) && InRange) {
			if(Monitorpanel.gameObject.activeInHierarchy == false){
				Monitorpanel.gameObject.SetActive(true);
				MonitorText.SetActive (true);
				playercontrols.Controllable = false;

			}else{
				Monitorpanel.gameObject.SetActive (false);
				MonitorText.SetActive (false);
				playercontrols.Controllable = true;
			}
		}
	}
}
