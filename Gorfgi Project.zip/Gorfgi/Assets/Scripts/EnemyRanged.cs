﻿using UnityEngine;
using System.Collections;

public class EnemyRanged : MonoBehaviour {
	
	public float timeBetweenAttacks = 3.5f;
	public GameObject Projectile;
	public float ProjectileSpeed = 3f;

	public GameObject TheParent;
	GameObject player;
	EnemyMovement enemyMovement;
	EnemyHealth enemyHealth;
	bool playerInRange;
	float timer;

	void Awake () {
		player = GameObject.FindGameObjectWithTag ("Player");
		enemyMovement = TheParent.GetComponent<EnemyMovement> ();
		enemyHealth = GetComponent<EnemyHealth> ();
	}

	void OnTriggerEnter (Collider other) {
	if (other.gameObject == player) {
			playerInRange = true;
			enemyMovement.enabled = false;
		}
	}

	void OnTriggerExit(Collider other){
		if (other.gameObject == player) {
			playerInRange = false;
			enemyMovement.enabled = true;
		}
	}

	void Update(){
		timer += Time.deltaTime;

		if (timer >= timeBetweenAttacks && playerInRange && enemyHealth.currentHealth > 0) {
			TheParent.transform.LookAt(player.transform);
			Attack();
		}
	}

	void Attack(){
		timer = 0f;
		Instantiate (Projectile);
		Projectile.transform.position = transform.position + Projectile.transform.forward * ProjectileSpeed;
	}
}
