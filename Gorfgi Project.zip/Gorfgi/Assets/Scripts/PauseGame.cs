﻿using UnityEngine;
using System.Collections;

public class PauseGame : MonoBehaviour {

	public Transform Pausepanel;
	GameObject player;
	PlayerControls playercontrols;

	void Start () {
		player = GameObject.FindGameObjectWithTag ("Player");
		playercontrols = player.gameObject.GetComponent<PlayerControls> ();
	}

	void Update () {
		if (Input.GetKeyDown (KeyCode.Escape)) {
			if(Pausepanel.gameObject.activeInHierarchy == false){
				Pausepanel.gameObject.SetActive(true);
				playercontrols.Controllable = false;
				Time.timeScale = 0;
			}else{
				Pausepanel.gameObject.SetActive (false);
				playercontrols.Controllable = true;
				Time.timeScale = 1;
			}
		}
	}

	public void QuitGame(){
		Application.LoadLevel ("MainMenu");
	}
}
