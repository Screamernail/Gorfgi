﻿public class GameSettings {
	public bool fullScreen;
	public int Difficulty;
	public float AllVolume;
}
