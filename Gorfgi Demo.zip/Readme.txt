Hi!

Before playing, you'll get to know the controls and the stability.


It's a click to move game. One mousekey to move and the other to
look at a point(You can't lookAt while moving). You have the space
key to shoot and E to use(Mostly green glowing computers here).

About the stability. In the first level, don't go to far to the south, into
a hill. The game's a-bit unstable and MAYBE a-bit too hard to get used
to but i can't do better than this.

By the way nothing happens when you die.